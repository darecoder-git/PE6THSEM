# Roommate Space

<aside>
💡 **Notion Tip:** Use this as the homepage for your... uh, home :) When you live with other people, this is an easy way to stick to rules, track finances, and more.

</aside>

# Rent

---

Rent is due the 15th of every month!

**TOTAL:** $3,500

- [ ]  Camille - $1000
- [ ]  Cory - $1000
- [ ]  Abigail - $1500

(Check your box when check is in the 📫)

**Property Manager #:** 555-555-555

**Lease agreement:**

[https://www.notion.so](https://www.notion.so)

# Internet + Tech

---

**Wifi Network**

`name-here`

**Password**

`password-here`

# Rules + Expenses

---

[123 Steiner St. Rules](Roommate%20S%2027afa/123%20Steine%2075947.md)

[Shared Expenses](Roommate%20S%2027afa/Shared%20Exp%20d107b.md)

[🗓 CALENDAR](Roommate%20S%2027afa/%F0%9F%97%93%20CALENDAR%202a228.csv)
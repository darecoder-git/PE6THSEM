# Machine Tool System

Course Link: https://deanza.instructure.com/courses/13517
Created: March 9, 2022 6:41 PM
Final Grade: IP
Instructor: Debashish Poddar
Quarter/Semester: Spring 2020
School: National Institute Of Technology
Semester Units: 2.7

[Notes](Machine%20To%2049ad8/Notes%207db65.csv)

- Class Information
    
    ### Contact and Office Hours:
    
    [fernandezpurba@fhda.edu](mailto:fernandezpurba@fhda.edu)
    
    By appointment
    
    ### Course Description:
    
    The location of people and activities throughout the world and understanding the reasons for their distribution will be examined. Topics covered include population and migration, human-environment relationships, geographies of language, religion, race and ethnicity, economic activities, political organization and settlement patterns including the urban environment.
    
    ### Course Syllabus:
    
    [Syllabus GEO 4 DA.pdf](Machine%20To%2049ad8/Syllabus_GEO_4_DA.pdf)
    

[Course Calendar Template](Machine%20To%2049ad8/Course%20Cal%2003dc1.csv)

---
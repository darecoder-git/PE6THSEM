# Automation and R

Created: March 9, 2022 6:41 PM
Final Grade: A
Instructor: Kishan Chaudhari
Quarter/Semester: Spring 2022
School: National Institute Of Technology
Semester Units: 3

### Course Description:

### Course Syllabus:

[SyllabusChivers15.01.pdf](Automation%20958f0/SyllabusChivers15.01.pdf)
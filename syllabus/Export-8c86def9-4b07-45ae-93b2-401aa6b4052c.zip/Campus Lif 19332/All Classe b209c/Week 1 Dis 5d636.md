# Week 1 Discussion:1. Theory of Metal Forming

Created: March 19, 2022 5:55 PM
Final Grade: A+
Instructor: RN Rai
Quarter/Semester: Spring 2022
School: National Institute Of Technology
Semester Units: 3

1. Theory of Metal Forming

**Metallurgical aspect of metal forming- Slip –twining-Mechanics of plastic deformationEffect of temperature, strain rate –microstructure and friction in metal forming-yield criteria
and their significance-classification of metal forming processes.**
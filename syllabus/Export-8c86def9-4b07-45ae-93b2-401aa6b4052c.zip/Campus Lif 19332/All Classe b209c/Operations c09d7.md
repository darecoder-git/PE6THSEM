# Operations Research

Created: March 9, 2022 6:41 PM
Final Grade: A
Instructor: Sujoy Chakraborty
Quarter/Semester: Spring 2022
School: National Institute Of Technology
Semester Units: 3

### Course Description:

Principles of Machine tools by A. Bhattacharya and G.C. Sen., Central Book Agency,
Kolkata.
2. Machine Tools vol.-I, II, III, IV BY Acharkan, Mir publishers.
UPE06B20: Operations Research

1. Linear Models

The phases of Operations research study- linear programming – Graphical methods –
Simplex algorithm—Duality – Transportation Problems – Assignment problems---
Applications to problems with discrete variables.
2. Network Models
Network Models--- shortest route--- Minimal spanning tree --- Maximum flow models----
Project network---- CPM and PERT networks--- Critical path scheduling--- Sequencing
models.
3. Inventory Models
Inventory models----Economic order quality models---- Quantity discount models---
Stochastic Inventory models---- Inventory control models in practice.
Queuing Theory
Queuing models--- Queuing system and structures --- Notation---Parameter --- Single Server
and multi--- Notation --- Parameter --- Single Server and multi server models--- Poisson input
--- Exponential service --- Component rate service --- Infinite population --- Simulation.
4. Decision Models
Decision Models--- Game Theory--- Two person Zero sum Game--- Graphical solution ---
Algebraic solution --- Linear programming solution – Replacement Models--- Models based
on service life --- Economic life --- Single or multivariable search techniques--- Application
or Models --- Case studies
Text Books

1. H.A.Taha “Operation Research” Prentice Hall of India 1999 6th Edition
2. S.Bhaskar “Operation Research” Anuradha Publishers Tamil Nadu 1999
References
3. Shennoy, Srivastava “Operation Research for Management” Willy Eastern -1994.
4. N.J.Bazara, Jarvis, H. Sherali “ A linear programming and Network Flows” , Joha Wiley
5. 
6. Philip and Ravindran “Operational Research “ , Joha Wiley , 1992.
7. Hiller and Lieberman “Operation Research “ Holden Day 1986.
8. Frank, S. Budnick, Dennis Mcleavy :Principals of Operation Research for Management”
Richad D Irwin -1990.
9. Sharma J.K. “Operation Research’ , Macmillan

### Course Syllabus:

[https://www.notion.so](https://www.notion.so)
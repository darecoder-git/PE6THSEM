# Machine Tool Design

Course Link: https://www.macmillanhighered.com/launchpad/roark8e/13461789#/ebook
Created: March 9, 2022 6:41 PM
Final Grade: IP
Instructor: Debashish Poddar
Quarter/Semester: Spring 2022
School: National Institute Of Technology
Semester Units: 3

- Quick Links
    
    ### Contact and Office Hours:
    
    [mujalcarlos@fhda.edu](mailto:mujalcarlos@fhda.edu)
    
    ### Course Description:
    
    American civilization from 1900 to the present. A survey of United States history (political, economic, intellectual, and social development).
    
    ### Course Syllabus:
    
    [Syllabus_ History 17C.pdf](Machine%20To%20eada5/Syllabus__History_17C.pdf)
    

---

[Course Calendar Template](Machine%20To%20eada5/Course%20Cal%20c2cdb.csv)
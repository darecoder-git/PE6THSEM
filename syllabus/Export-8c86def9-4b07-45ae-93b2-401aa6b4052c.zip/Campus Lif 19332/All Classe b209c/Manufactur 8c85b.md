# Manufacturing Process II

Course Link: https://deanza.instructure.com/courses/12363
Created: March 9, 2022 6:41 PM
Final Grade: A
Instructor: RN Rai
Quarter/Semester: Spring 2022
School: National Instititute Of Technology Agartala
Semester Units: 3

- Quick Links
    
    ### Contact and Office Hours:
    
    hedgesalicia@fhda.edu
    
    Mondays from 10am-12pm on Zoom
    
    ### Course Description:
    
    The anthropological approach to the study of human behavior from a cross-cultural, comparative perspective. An exploration into the languages, subsistence, economics, sociopolitical systems, religions, and world views of diverse world cultures. An assessment of the dynamics of culture change and future prospects for humanity.
    
    ### Course Syllabus:
    
    [Anth002SyllabusSpring2020.pdf](Manufactur%208c85b/Anth002SyllabusSpring2020.pdf)
    
    ---
    

---

-
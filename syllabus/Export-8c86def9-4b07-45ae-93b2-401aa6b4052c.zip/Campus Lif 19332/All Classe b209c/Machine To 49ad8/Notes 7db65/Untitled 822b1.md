# Untitled

Tags: Lecture

Metallurgical aspect of metal forming- Slip –twining-Mechanics of plastic deformationEffect of temperature, strain rate –microstructure and friction in metal forming-yield criteria
and their significance-classification of metal forming processes.
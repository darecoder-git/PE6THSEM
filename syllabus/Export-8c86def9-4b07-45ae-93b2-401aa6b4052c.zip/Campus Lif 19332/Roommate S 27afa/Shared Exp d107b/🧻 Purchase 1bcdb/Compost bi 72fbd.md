# Compost bin

Bought: Yes
Per Person: 6.67
Purchaser: Ivan Zhao
Total: 20
# Vacuum cleaner

Bought: Yes
Per Person: 41
Purchaser: Simon
Total: 123
# October Rent Due!

Date: September 15, 2019
Person in Charge: Mike Shafer
Type: Rent
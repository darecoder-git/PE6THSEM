# Kia's Birthday Party

Comments: I will clean up! Absolutely do not worry about it.
Date: September 18, 2019
Person in Charge: Mike Shafer
Rooms: Dining Room, Kia's Room, Kitchen, Living Room
Type: Party 🎉
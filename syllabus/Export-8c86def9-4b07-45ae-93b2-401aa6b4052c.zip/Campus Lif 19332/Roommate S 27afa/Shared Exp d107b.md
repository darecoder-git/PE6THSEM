# Shared Expenses

<aside>
💡 **Notion Tip:** You can use this handy table to figure out how to split shared expenses and purchases evenly between you and your roommates. The example below assumes 3 roommates. Click any cell under `Per Person` to edit this.

</aside>

[🧻 Purchases ](Shared%20Exp%20d107b/%F0%9F%A7%BB%20Purchase%201bcdb.csv)
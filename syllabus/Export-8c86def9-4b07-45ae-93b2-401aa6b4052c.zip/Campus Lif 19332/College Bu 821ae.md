# College Budget

# Monthly Cap: $1,250

<aside>
🔥 **Refill dining hall card!**

</aside>

[Expenses](College%20Bu%20821ae/Expenses%20ab393.csv)
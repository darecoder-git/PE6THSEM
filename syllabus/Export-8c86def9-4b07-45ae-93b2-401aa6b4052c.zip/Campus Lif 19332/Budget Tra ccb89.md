# Budget Tracker

<aside>
💡 **Notion Tip:** Keep track of your expenses and how they compare to a monthly cap. Click `All Expenses` to view this data different ways using filters — like August expenses only, or home expenses only. [Learn more about filters here](https://www.notion.so/Intro-to-databases-fd8cd2d212f74c50954c11086d85997e).

</aside>

# Monthly Cap: $3,500

[Expenses](Budget%20Tra%20ccb89/Expenses%20496e6.csv)
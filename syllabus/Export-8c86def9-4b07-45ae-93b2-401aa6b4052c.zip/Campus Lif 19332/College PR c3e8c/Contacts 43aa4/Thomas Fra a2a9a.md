# Thomas Frank

Class: Productivity 305
College Prof.: No
Last Contacted: May 12, 2017
Last Update?: Making some dope vids!
Status: Time to reach out!

- May 12
    
    Meeting on his podcast
    
    Uhhhhhh, what a throwback! (I'm less self-centered now!)
    
    [https://open.spotify.com/embed-podcast/episode/2JBExEI7tGFiMl0ewQcSi4](https://open.spotify.com/embed-podcast/episode/2JBExEI7tGFiMl0ewQcSi4)
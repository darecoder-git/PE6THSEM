# Princess Leia

Class: Star Wars 201
College Prof.: No
Last Contacted: April 17, 2020
Last Update?: Rushing Alpha Kappa Chai Latte
Status: Time to reach out!

## Address:

## Family members:

## Likes:

## 🎁 Gift ideas:

## Miscellaneous notes:
# Matt D'Avella

Class: Minimalism 400
College Prof.: No
Last Contacted: April 1, 2020
Last Update?: Livin' it up.
Status: Time to reach out!

- April 1
    
    April fools!
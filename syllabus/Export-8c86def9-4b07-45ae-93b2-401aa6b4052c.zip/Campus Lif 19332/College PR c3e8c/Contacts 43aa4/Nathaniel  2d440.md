# Nathaniel Drew

Class: Simplicity 101
College Prof.: No
Last Contacted: April 17, 2020
Last Update?: Living in France, but quarantined.
Status: Time to reach out!

- April 16
    - Gonna make another video!
- April 17
    - Discussing the irreverent comedy Mrs. Maisel
        - He thinks it really reflects upper-middle class Judaism in New York in '50s, while I just watch it eating popcorn
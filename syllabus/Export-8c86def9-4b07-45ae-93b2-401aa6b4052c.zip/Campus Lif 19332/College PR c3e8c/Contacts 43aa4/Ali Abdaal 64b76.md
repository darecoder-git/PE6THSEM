# Ali Abdaal

Class: Notetaking 208
College Prof.: No
Last Contacted: April 15, 2020
Last Update?: 600K subs!
Status: Time to reach out!

- Toggle :)
    
    Yeah man, we should really meet up sometime soon!
    
-
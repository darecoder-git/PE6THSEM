# Costco Run

Amount: 109
Category: Groceries
Date: September 11, 2019
# Laundry

Amount: 3.5
Category: Personal Expenses
Comment: Ask Kunle to use his laundry.
Date: September 10, 2019
# Cell Phone

Amount: 80
Category: Personal Expenses
Date: August 14, 2019
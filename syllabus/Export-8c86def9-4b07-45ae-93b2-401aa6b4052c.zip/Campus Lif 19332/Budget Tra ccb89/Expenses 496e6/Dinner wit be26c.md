# Dinner with Ashley

Amount: 34
Category: Food
Comment: Go somewhere less $$ next time!
Date: August 12, 2019
# Week 1 Discussion:UPE06B19: Machine Tool System

Class: MPII
Complete: No
Due: April 23, 2020
Type: Discussion

**UPE06B19: Machine Tool System
Principles of generations of various surfaces in machine tools; Conformable Kinematic
Synthesis for tracing , Forming, Enveloping and Generation; Kinematic Structure of Gear and
step less Drive for machines ; Designing Discrete step Drives for Machine Tools speed and**
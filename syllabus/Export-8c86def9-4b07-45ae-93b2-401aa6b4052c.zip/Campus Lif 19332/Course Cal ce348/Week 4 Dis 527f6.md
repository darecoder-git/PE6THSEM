# Week 4 Discussion:Sheet Metal Forming Processes

Class: UPE06B18
Complete: No
Due: May 1, 2022
Type: Discussion

**Forging and Rolling process
Principal-Classification-equipment, tooling-processes, parameters and calculation of force
during forging and rolling process-Ring compression tests-Post forming heat treatmentDefect (cause and remedy)-application**
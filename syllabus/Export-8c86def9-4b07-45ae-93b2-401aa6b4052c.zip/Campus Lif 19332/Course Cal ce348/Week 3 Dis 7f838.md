# Week 3 Discussion: Extrusion and Drawing Process

Class: UPE06B18
Complete: No
Due: May 15, 2020
Type: Discussion

**Classification of extrusion process –tool, equipment principal of this process –influence of
friction –Extrusion forces calculation –Defects and analysis –Rod /Wire drawing –tools,
Equipment and principal of process –defects –Tube drawing and sinking processes –
Mannesmann processes of seamless pipe manufacturing ,
4**
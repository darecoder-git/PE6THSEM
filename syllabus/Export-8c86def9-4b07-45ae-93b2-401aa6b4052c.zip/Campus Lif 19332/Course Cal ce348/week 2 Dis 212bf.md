# week 2 Discussion MPII

Class: MPII
Complete: No
Due: May 7, 2020
Type: Discussion

**feed ; Step less Drive ; Design Principles of Machines Tool Gear Boxes ; hydraulic and
Electric drives and control; Machine tool structures; Principles of design of Machine tool
elements like bearings spindles and slides; Automation and control features of Machine tools;
special tools and attachment. Elements of unit build machines and Transfer lines; Selection
and acceptance testing of Machine tools.**
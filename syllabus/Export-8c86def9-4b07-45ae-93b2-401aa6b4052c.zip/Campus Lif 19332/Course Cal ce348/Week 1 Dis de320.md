# Week 1 Discussion:Theory of Metal Forming

Class: UPE06B18
Complete: No
Due: April 24, 2020
Type: Discussion

:

1. **Theory of Metal Forming
Metallurgical aspect of metal forming- Slip –twining-Mechanics of plastic deformationEffect of temperature, strain rate –microstructure and friction in metal forming-yield criteria
and their significance-classification of metal forming processes.**
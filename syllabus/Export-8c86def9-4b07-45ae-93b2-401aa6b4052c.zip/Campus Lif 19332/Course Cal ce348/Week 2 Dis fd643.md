# Week 2 Discussion: 2. Forging and Rolling process

Class: UPE06B18
Complete: No
Due: May 8, 2020
Type: Discussion

**Principal-Classification-equipment, tooling-processes, parameters and calculation of force
during forging and rolling process-Ring compression tests-Post forming heat treatmentDefect (cause and remedy)-application**
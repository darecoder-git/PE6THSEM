# References

Class: UPE06B18
Complete: No
Type: Exam

**Text books**

1. **Narayanasamy, R., “Metal working Technology”, Prentice Hall (1997).
References**
2. **Dieter, “Mechanical Metallurgy”, Revised Edition, 1992.**
3. **George E,”Dieter –Engineering Design (A Materials and processing Approach)” McGraw
Hill-Edition II- University of Maryland-1991**
4. **SEROPE KALPAKJJAN, “Manufacturing Engineering and Technology,” Edition –III –
addision—Wesley Publishing co.1985,**
5. **William F.Hosford and Robert M, Caddlel , “Metal forming ,” (Mechanics and Metallurgy
), Prentice Hall Publishing co, 1990.**
6. **Sinha and Prasad, “Theory of metal forming and metal cutting ,” Dhanpat Rai
Pub,(P)Ltd,.1999**
7. **Rao P.N,” Manufacturing Technology,” TMH Ltd 1998(Revise edition)**
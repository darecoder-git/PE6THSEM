# Week 5 Discussion:Super plastic forming

Class: UPE06B18
Complete: No
Type: Discussion

**Super plastic forming –electroforming –fine balancing, P/M forging –Isothermal forging –
High Speed, hot forging –high velocity extrusion**
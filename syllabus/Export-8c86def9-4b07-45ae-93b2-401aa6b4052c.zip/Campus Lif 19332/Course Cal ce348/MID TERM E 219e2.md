# MID TERM Exam

Class: UPE06B18
Complete: No
Due: March 4, 2022
Type: Exam

+

1. **Theory of Metal Forming
Metallurgical aspect of metal forming- Slip –twining-Mechanics of plastic deformationEffect of temperature, strain rate –microstructure and friction in metal forming-yield criteria
and their significance-classification of metal forming processes.**
2. **Forging and Rolling process
Principal-Classification-equipment, tooling-processes, parameters and calculation of force
during forging and rolling process-Ring compression tests-Post forming heat treatmentDefect (cause and remedy)-application**
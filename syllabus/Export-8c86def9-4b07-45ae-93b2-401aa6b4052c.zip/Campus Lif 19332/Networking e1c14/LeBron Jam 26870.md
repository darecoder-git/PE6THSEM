# LeBron James

Company: Los Angeles Lakers
Email Address: lebron@lakers.com
How We Met? (Ex. Place): Staples Center 
Industry: Sports
When Did We Meet?: April 3, 2020
# Job Applications

<aside>
💡 **Notion Tip:** Stay on top of job applications. (Also great for tracking internship apps!)

</aside>

### Current Resume

[https://www.notion.so](https://www.notion.so)

### Cover Letter Template

[https://www.notion.so](https://www.notion.so)

### Portfolio

[]()

<aside>
👇 **Notion Tip:** Click `All Applications` to organize them by stage or view due dates on the calendar.

</aside>

[Applications](Job%20Applic%20db81b/Applicatio%2006be3.csv)

# Drafts

Draft customized versions of your resume and cover letters here.

[Working draft of resume](Job%20Applic%20db81b/Working%20dr%20c35d2.md)
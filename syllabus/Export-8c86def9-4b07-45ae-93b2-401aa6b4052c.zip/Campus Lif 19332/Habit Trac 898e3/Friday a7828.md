# Friday

Date: June 1, 2020
✍🏼Journaling: Yes
👟Running: Yes
📱Screen Time (minutes): 60
😴7+ hrs Sleep: Yes
🧘🏽‍♀️Meditation: Yes
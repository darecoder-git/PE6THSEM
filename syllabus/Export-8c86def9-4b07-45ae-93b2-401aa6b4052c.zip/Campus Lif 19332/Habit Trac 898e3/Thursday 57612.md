# Thursday

Date: June 21, 2020
✍🏼Journaling: No
👟Running: No
😴7+ hrs Sleep: No
🧘🏽‍♀️Meditation: No
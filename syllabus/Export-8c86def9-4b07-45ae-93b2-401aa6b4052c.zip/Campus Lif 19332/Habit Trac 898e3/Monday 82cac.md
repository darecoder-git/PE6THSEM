# Monday

Date: June 18, 2020
✍🏼Journaling: No
👟Running: No
😴7+ hrs Sleep: No
🧘🏽‍♀️Meditation: No
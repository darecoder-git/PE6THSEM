# Sunday

Date: June 3, 2020
✍🏼Journaling: No
👟Running: No
😴7+ hrs Sleep: No
🧘🏽‍♀️Meditation: No
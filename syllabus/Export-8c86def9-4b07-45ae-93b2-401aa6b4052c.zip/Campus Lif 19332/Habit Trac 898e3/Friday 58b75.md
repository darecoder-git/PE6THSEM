# Friday

Date: June 15, 2020
✍🏼Journaling: No
👟Running: No
😴7+ hrs Sleep: No
🧘🏽‍♀️Meditation: No
# Acme, Inc.

Due Date: June 15, 2019
Position: Software Engineering Intern
Posting URL: https://acmecorp.com
Resume: resume.pdf
Stage: Offered 😃

<aside>
💡 Create a new page and select `New Role` from the list of template options to generate the format below. Get your talking points and next steps on lock.

</aside>

# Action items

- [ ]  

# Notes on the company

- 

# Where can I add value?

- 

# What am I excited about? What will I learn?

- 

# Notes on recruiter/hiring manager

-
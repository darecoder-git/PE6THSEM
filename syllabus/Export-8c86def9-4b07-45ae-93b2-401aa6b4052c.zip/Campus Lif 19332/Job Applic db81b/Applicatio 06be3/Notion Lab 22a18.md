# Notion Labs, Inc.

Position: Software Engineering Intern
Posting URL: https://notion.so
Stage: Followed-up! 💌

<aside>
💡 Create a new page and select `New Role` from the list of template options to generate the format below. Get your talking points and next steps on lock.

</aside>

# Action items

- [ ]  

# Notes on the company

- 

# Where can I add value?

- 

# What am I excited about? What will I learn?

- 

# Notes on recruiter/hiring manager

-
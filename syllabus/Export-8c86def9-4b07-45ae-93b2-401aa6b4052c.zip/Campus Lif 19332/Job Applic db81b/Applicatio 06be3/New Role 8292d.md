# New Role

# Action items

- [ ]  

# Notes on the company

- 

# Where can I add value?

- 

# What am I excited about? What will I learn?

- 

# Notes on recruiter/hiring manager

-
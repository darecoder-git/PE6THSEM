# Working draft of resume

<aside>
💡 Use this space to draft versions of your resume for each role.

</aside>

# Name

**Byline** 

---

### Personal Statement

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

### Education

1. **Secondary** XXXX - XXXX
    
    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
    
2. **Postsecondary:** XXXX - XXXX
    
    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
    

### Experience

1. **First working experience** XXXX - XXXX
    
    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
    
2. **Campus job** XXXX - XXXX
    
    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
    

### Skills

- **Lorem ipsum**
    
    Example 
    
- **Lorem ipsum**
    
    Example 
    
- **Lorem ipsum**
    
    Example
# What to Pack for College?

<aside>
🔑 A checklist for college move-in. Feel free to customize this.

</aside>

## 🛏️ Bath and Bedding

- [ ]  Comforter and/or quilts (Consider bringing sturdy, easy-to-wash items)
- [ ]  Throw blanket
- [ ]  Bed sheets (Suggested Size: Twin XL)
- [ ]  Pillows
- [ ]  Pillowcases
- [ ]  Mattress pad
- [ ]  Reading pillow
- [ ]  Alarm clock
- [ ]  Tissue
- [ ]  Paper towels
- [ ]  Under bed storage
- [ ]  Towels: bath, washcloths and hand towels. Consider putting your name on a tag in permanent marker, especially if you have plain white or other “anonymous” towels
- [ ]  Shower shoes (Community Showers)
- [ ]  Shower bucket/basket/caddy to carry items
- [ ]  Extra pillow(s) if you will lounge/study on the bed.

## 🚿 Health and Grooming

- [ ]  Shower gel or bath soap
- [ ]  Shower Cap
- [ ]  Shampoo and conditioner
- [ ]  Deodorant
- [ ]  Hair grooming tools (combs, hair dryer, brush)
- [ ]  Toothbrush and toothpaste
- [ ]  Lotion/ skin cosmetics
- [ ]  Bathrobe (Especially important if the shower is down the hall!)
- [ ]  Travel soap container
- [ ]  Dental floss
- [ ]  Eye drops
- [ ]  Q-tips
- [ ]  Mouthwash
- [ ]  Nail clippers
- [ ]  Loofah
- [ ]  Cotton swabs
- [ ]  Shaving kit
- [ ]  Handheld mirror
- [ ]  First Aid kit, including basic adhesive bandages, vitamins, aspirin, cough drops etc. (This will cut down on trips to the health center!)
- [ ]  Prescription medicines and copies of each prescription
- [ ]  Bathroom cleaning products (if you need to clean)
- [ ]  Shower mat
- [ ]  Air Freshener

## 🎒 School Supplies

- [ ]  A sturdy backpack or book bag for everyday use
- [ ]  Computer and any necessary supplies/accessories.
- [ ]  Calendar or planner
- [ ]  Pens
- [ ]  Paper
- [ ]  Pencils
- [ ]  Notebooks
- [ ]  Binders
- [ ]  Paperclips
- [ ]  Sticky notes
- [ ]  Highlighters
- [ ]  Calculator
- [ ]  Earphones
- [ ]  Extension cord
- [ ]  Computer Mouse
- [ ]  Index Cards

## 💳 Misc.

- [ ]  Umbrella
- [ ]  A large backpack or shoulder bag for possible weekend trips you might take
- [ ]  Car registration & insurance
- [ ]  Medical insurance card
- [ ]  Driver’s license
- [ ]  Student ID
- [ ]  Financial aid forms
- [ ]  Debit card
- [ ]  Emergency contacts
# Dinner w/Cheryl

Amount: 34
Category: Food
Comment: Go somewhere less $$ next time!
Date: September 12, 2019
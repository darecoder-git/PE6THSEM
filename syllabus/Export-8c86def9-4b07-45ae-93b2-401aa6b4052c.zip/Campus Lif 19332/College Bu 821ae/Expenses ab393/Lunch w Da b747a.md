# Lunch w/Dad

Amount: 21
Category: Food
Date: September 11, 2019
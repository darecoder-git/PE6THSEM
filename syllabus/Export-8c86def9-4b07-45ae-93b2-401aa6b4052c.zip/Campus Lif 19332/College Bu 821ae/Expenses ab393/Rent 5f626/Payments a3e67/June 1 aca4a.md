# June 1

Rent: 525
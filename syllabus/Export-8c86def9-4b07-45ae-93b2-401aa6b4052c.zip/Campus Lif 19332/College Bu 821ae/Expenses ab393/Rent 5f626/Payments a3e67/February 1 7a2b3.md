# February 1

Rent: 525
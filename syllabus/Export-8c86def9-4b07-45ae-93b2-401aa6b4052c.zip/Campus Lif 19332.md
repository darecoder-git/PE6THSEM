# Campus Life - Organizer

> Using Notion to manage your campus life.
> 

- **Planner**: For organizing events like "When are classes going to start?".
- **Weekly Time Blocking**: Planning out every moment of your day in advance and dedicating specific time “blocks” for certain tasks and responsibilities.
- **Networking - CRM**: Keep track of the contacts you meet in school.
- **Goals**: Make goals for the year and track them.
- **Job Applications**: Keep track of the internships and full-time jobs you apply to.
- **Habit Tracker**: Keep yourself accountable! Make sure you get that sleep.
- **What To Bring to Campus?** - A list you can use every year for moving-in.
- **Budget Tracker**: Keep track of your expenses and making sure you don't drain your bank account.

---

[Planner](Campus%20Lif%2019332/Planner%20ab3c1.csv)

[Weekly Time Blocking](Campus%20Lif%2019332/Weekly%20Tim%203bda1.csv)

[Networking - CRM](Campus%20Lif%2019332/Networking%20e1c14.csv)

[Goals](Campus%20Lif%2019332/Goals%2010e1f.csv)

[Job Applications](Campus%20Lif%2019332/Job%20Applic%20db81b.md)

[Habit Tracker](Campus%20Lif%2019332/Habit%20Trac%20898e3.csv)

[What to Pack for College?](Campus%20Lif%2019332/What%20to%20Pa%20fe481.md)

[Budget Tracker](Campus%20Lif%2019332/Budget%20Tra%20ccb89.md)

<aside>
📗 **Current Classes**

</aside>

[All Classes](Campus%20Lif%2019332/All%20Classe%20b209c.csv)

[TQM-Elective 1](Campus%20Lif%2019332/TQM-Electi%20bf20a.md)

---

[Course Calendar Template](Campus%20Lif%2019332/Course%20Cal%20ce348.csv)

<aside>
🖇️ **Quick Links**

</aside>

[Calendar ↗︎](https://calendar.google.com/calendar/r) | [Google Drive ↗︎](https://drive.google.com) | [Canvas ↗︎](https://deanza.instructure.com/) | [Launchpad ↗︎](https://www.macmillanhighered.com/launchpad/roark8e/13461789#/ebook)

[Bill Pay ↗︎](https://secure.touchnet.com/C20757_tsa/web/welcome.jsp) | [Rent Payment ↗︎](https://www.paypal.com/myaccount/transfer/homepage)

[Roommate Space](Campus%20Lif%2019332/Roommate%20S%2027afa.md)

[College Budget](Campus%20Lif%2019332/College%20Bu%20821ae.md)

[College PRM](Campus%20Lif%2019332/College%20PR%20c3e8c.md)